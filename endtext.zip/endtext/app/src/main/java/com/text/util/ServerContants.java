package com.text.util;

public class ServerContants {
    private static final String ROOTADDRESSS="http://10.11.254.28:8080";


    public static String NEED_LOGIN="";
    public static String NEED_SEARCH="";
    static {

        NEED_LOGIN+=ROOTADDRESSS+"/need/registNeed";
        NEED_SEARCH+=ROOTADDRESSS+"/need/searchNeed";

    }

}
