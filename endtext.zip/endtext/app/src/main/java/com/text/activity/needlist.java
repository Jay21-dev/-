package com.text.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.example.endtext.R;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.text.adapter.NeedAdapter;
import com.text.util.HttpCallback;
import com.text.util.HttpUtil;
import com.text.util.ServerContants;
import com.text.vo.Need;
import com.text.vo.Result;
import com.text.vo.Result1;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class needlist extends AppCompatActivity {
    //数据控件
    private List<Need> needs = new ArrayList<Need>();
    private NeedAdapter adapter;
    private ListView listView;
    private int resourceId;

    private Handler mHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.needlist_activity);
        resourceId = R.layout.example;
        adapter = new NeedAdapter(needs, resourceId, this);
        listView = findViewById(R.id.lv);

        listView.setAdapter(adapter);


        mHandler = new Handler() {
            @SuppressLint("HandlerLeak")
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {
                    case 1:

                        GsonBuilder builder = new GsonBuilder();
                        builder.setDateFormat("MMM dd, yyyy, h:mm:ss a"); // 设置自定义的日期格式
                        Gson gson = builder.create();

                        Result1 result = gson.fromJson(msg.obj.toString(), Result1.class);
                        if (result.getCode() == 0) {
                            String listJson = gson.toJson(result.getData());
                            Type listType = new TypeToken<List<Need>>(){}.getType();
                            List<Need> newNeed = gson.fromJson(listJson, listType);
                            if (newNeed != null && !newNeed.isEmpty()) {
                                needs.clear();
                                needs.addAll(newNeed);
                                adapter.notifyDataSetChanged();
                            }
                        } else {
                            Toast.makeText(needlist.this, result.getMsg(), Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case 2:
                        Toast.makeText(needlist.this, msg.obj.toString(), Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        };
        getData();
    }
    public void lendd(View view) {
        Intent intent=new Intent(needlist.this, lend.class);
        startActivity(intent);

    }

    private void getData() {
        HttpUtil.requestApi(ServerContants.NEED_SEARCH, "POST", null,new HttpCallback() {
            @Override
            public void onSuccess(InputStream input) {
                Message message=new Message();
                message.obj=HttpUtil.decodeInputStreamByString(input);
                message.what=1;
                mHandler.sendMessage(message);
            }

            @Override
            public void onFailure(InputStream error) {
                Message message=new Message();
                message.obj=HttpUtil.decodeInputStreamByString(error);
                message.what=2;
                mHandler.sendMessage(message);
            }
        });

}

}
