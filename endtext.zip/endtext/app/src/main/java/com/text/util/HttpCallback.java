package com.text.util;

import java.io.InputStream;

public interface HttpCallback {
    void onSuccess(InputStream input);
    void onFailure(InputStream error);
}
