package com.text.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class HttpUtil {
    public static void requestApi(String urlStr,String method,String param,HttpCallback callback){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url=new URL(urlStr);
                    HttpURLConnection conn=(HttpURLConnection)url.openConnection();
                    conn.setRequestMethod(method);
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    if (method.equalsIgnoreCase("post")){
                        conn.setDoOutput(true);
                        conn.setUseCaches(false);
                        if(param!=null && !param.isEmpty()){
                            OutputStream out=conn.getOutputStream();
                            out.write(param.getBytes());
                            out.flush();
                        }

                    }
                    conn.connect();
                    if (conn.getResponseCode() == 200) {
                        InputStream inputStream = conn.getInputStream();
                        callback.onSuccess(inputStream);
                    } else {
                        // 修改这里使用 conn.getErrorStream() 获取错误流
                        InputStream errorStream = conn.getErrorStream();
                        callback.onFailure(errorStream);
                    }

                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();
    }

    public static String decodeInputStreamByString(InputStream inputStream)  {
        StringBuilder result=new StringBuilder();
        BufferedReader buff=new BufferedReader(new InputStreamReader(inputStream));
        String line="";
        try {
            while ((line=buff.readLine())!=null){
                result.append(line);
            }
        }catch (IOException e){

        }
        return result.toString();
    }
}
