package com.text.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.endtext.R;
import com.text.util.HttpCallback;
import com.text.util.HttpUtil;
import com.text.util.ServerContants;

import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class lend extends AppCompatActivity {
    private Button registBtn;
    private EditText titleEdt;
    private EditText describeEdt;
    private EditText startEdt;
    private EditText endEdt;
    private EditText phoneEdt;

    private Handler mHandler;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lend_activity);

        registBtn=findViewById(R.id.tv_regist);
        titleEdt=findViewById(R.id.tv_title);
        describeEdt=findViewById(R.id.tv_describle);
        startEdt=findViewById(R.id.tv_start);
        endEdt=findViewById(R.id.tv_end);
        phoneEdt=findViewById(R.id.tv_phone);
        mHandler=new Handler(){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                switch (msg.what){
                    case 1:
                        Intent intent=new Intent(lend.this,needlist.class);
                        startActivity(intent);
                        Toast.makeText(lend.this,"成功了",Toast.LENGTH_SHORT).show();

                        break;
                    case 2:
                        Toast.makeText(lend.this,"失败了",Toast.LENGTH_SHORT).show();
                }
            }



        };








        registBtn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                String title=titleEdt.getText().toString();
                String describe=describeEdt.getText().toString();
                String starttime=startEdt.getText().toString();
                String endtime=endEdt.getText().toString();
                String phone=phoneEdt.getText().toString();


                long start_time = convertToTimestamp(starttime);
                long end_time = convertToTimestamp(endtime);
                String url = ServerContants.NEED_LOGIN + "?title=" + title + "&describe=" + describe +
                        "&start_time=" + start_time + "&end_time=" + end_time + "&phone=" + phone;


                HttpUtil.requestApi(url,"GET",null, new HttpCallback() {
                    @Override
                    public void onSuccess(InputStream input) {
                        Message message=new Message();
                        message.obj=HttpUtil.decodeInputStreamByString(input);
                        message.what=1;
                        mHandler.sendMessage(message);
                    }

                    @Override
                    public void onFailure(InputStream error) {
                        Message message=new Message();
                        message.obj=HttpUtil.decodeInputStreamByString(error);
                        message.what=2;
                        mHandler.sendMessage(message);
                    }
                });
            }
        });
    }
    // 辅助方法：将日期时间字符串转换为时间戳
    private long convertToTimestamp(String dateTimeStr) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = dateFormat.parse(dateTimeStr);
            return date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return 0; // 或者处理日期时间格式错误的情况
        }
    }


}