package com.text.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.endtext.R;
import com.text.vo.Need;

import java.text.SimpleDateFormat;
import java.util.List;

public class NeedAdapter extends BaseAdapter {
    private List<Need> needs;
    private int resourceId;
    private Context mContext;


    public NeedAdapter(List<Need> stations, int resourceId, Context mContext) {
        this.needs = stations;
        this.resourceId = resourceId;
        this.mContext = mContext;
    }
    @Override
    public int getCount() {
        return needs.size();
    }

    @Override
    public Object getItem(int i) {
        return needs.get(i);
    }

    @Override
    public long getItemId(int i) {
        return needs.get(i).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //1、找到子布局
        View view;
        ViewHolder holder = null;
        if(convertView == null){
            view = LayoutInflater.from(mContext).inflate(resourceId, parent, false);
            //3、找到子布局中的控件
            holder  = new ViewHolder();
            holder.titleTv=view.findViewById(R.id.e_title1);
            holder.describeTv=view.findViewById(R.id.e_describle1);
            holder.startTv=view.findViewById(R.id.e_start);
            holder.endTv=view.findViewById(R.id.e_end);
            holder.phoneTv=view.findViewById(R.id.e_phone);
            holder.photoTv=view.findViewById(R.id.iv_img);


            view.setTag(holder);
        }else{
            view = convertView;
            holder = (ViewHolder) view.getTag();
        }
        Need need=needs.get(position);

        holder.titleTv.setText(need.getTitle());
        holder.describeTv.setText(need.getDescribe());

        // 格式化时间戳为可读的日期时间字符串
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedStart = dateFormat.format(new java.util.Date(need.getStart_time().getTime()));
        String formattedEnd = dateFormat.format(new java.util.Date(need.getEnd_time().getTime()));

        holder.startTv.setText(formattedStart); // 设置开始时间
        holder.endTv.setText(formattedEnd); // 设置结束时间


        holder.phoneTv.setText(need.getPhone());
        byte[] photoData = need.getPhoto3();
        if (photoData != null) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(photoData, 0, photoData.length);
            holder.photoTv.setImageBitmap(bitmap);
        }


        return view;
    }

    public class ViewHolder{
        public TextView titleTv;
        public TextView describeTv;
        public TextView startTv;
        public TextView endTv;
        public TextView phoneTv;
        public ImageView photoTv;

    }

}
