package com.example.demo.service;

import com.example.demo.dao.NeedMapper;
import com.example.demo.vo.Need;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class NeedService {

    @Autowired
    private NeedMapper needMapper;


    public  List<Need> searchAll(String keyword){
        if (keyword==null||keyword.isEmpty()){
            return needMapper.findAll();
        }else {
            return needMapper.searchAll(keyword);
        }
    }

public int saveNeed(String title, String describe, Timestamp start_time, Timestamp end_time, String phone) {
    // 将时间戳转换为 Timestamp 对象（如果需要）
    return needMapper.saveNeed(title, describe, start_time, end_time, phone);
}




}
