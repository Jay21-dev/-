package com.example.demo.controller;

import com.example.demo.service.NeedService;
import com.example.demo.vo.Need;
import com.example.demo.vo.Result1;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.sql.Timestamp;
import java.util.List;

@Controller
@RequestMapping("/need")
public class NeedController {

    @Autowired
    private NeedService needService;

@GetMapping("/registNeed")
@ResponseBody
public String regist(String title, String describe, long start_time, long end_time, String phone) {
    Result1 result = new Result1();

    // 将时间戳转换为 Timestamp 对象（如果需要）
    Timestamp startTimeStamp = new Timestamp(start_time);
    Timestamp endTimeStamp = new Timestamp(end_time);

    needService.saveNeed(title, describe, startTimeStamp, endTimeStamp, phone);
    result.setMsg("注册成功");
    result.setData(null);
    return new Gson().toJson(result);
}


    @PostMapping("/searchNeed")
    @ResponseBody
    public String searchNeeds(String keyword){
        Result1 result=new Result1();

        List<Need> needs= needService.searchAll(keyword);

        if (needs==null||needs.size()==0){
            result.setCode(-1);
            result.setMsg("暂无数据");
        }else {
            result.setCode(0);
            result.setMsg("数据获取成功");
            result.setData(needs);
        }
        return new Gson().toJson(result);
    }




}
