package com.example.demo.dao;

import com.example.demo.vo.Need;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.sql.Timestamp;
import java.util.List;

@Mapper
public interface NeedMapper {
    @Select("select * from need where title like CONCAT('%',#{keyword},'%')")
    List<Need> searchAll(String keyword);

    @Insert("insert into need(title,`describe`, start_time, end_time, phone)values(#{title}, #{describe}, #{start_time}, #{end_time}, #{phone})")
    int saveNeed(
//            @Param("id") Integer id,
            @Param("title") String title,
            @Param("describe") String describe,
            @Param("start_time") Timestamp start_time,
            @Param("end_time") Timestamp end_time,
            @Param("phone") String phone
    );
    @Select("select * from `need`")
    List<Need> findAll();

}
